const sharp = require('sharp');

// Pour les images d'étapes
['etape1', 'etape2', 'etape3'].forEach(etape => {
  sharp(`etapes/${etape}.webp`)
    .resize(800, 450, { fit: 'cover' })
    .webp({ quality: 85 })
    .toFile(`etapes/${etape}-optimized.webp`);
});